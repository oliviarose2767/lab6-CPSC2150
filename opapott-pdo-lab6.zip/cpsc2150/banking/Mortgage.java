/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.banking;

/**
 * @invariant 0 <= cost
 * @invariant 0 <= downPayment
 * @invariant 0 <= years
 * @invariant 0 <= customer.creditScore <= 850 && 0 <= customer.MonthlyDebt && 0 <= customer.Income
 * @invariant 0 < D2I
 * @invariant 0 < payment
 * @invariant 0 <= rate <= 1
 *
 * Correspondence cost_of_house = cost
 * Correspondence down_payment = downPayment
 * Correspondence number_of_years = years
 * Correspondence customer_information = customer
 * Correspondence debt_to_income_ratio = D2I
 * Correspondence monthly_loan_payment = payment
 * Correspondence annual_percentage_rate = rate
 */
public class Mortgage extends AbsMortgage implements IMortgage{

    private double cost;
    private double downPayment;
    private int years;
    private ICustomer customer;
    private double D2I;
    private double payment;
    private double rate;

    /**
     *
     * @param c is cost of home
     * @param dp is the down payment
     * @param y is the number of years
     * @param ic is the customer object
     * @post Mortage(c, dp, y, ic)
     */
    Mortgage(double c, double dp, int y, ICustomer ic){
        cost = c;
        downPayment = dp;
        years = y;
        customer = ic;

        rate = calc_rate();
        payment = calc_payment();

        //Damion said 12 is okay as a "magic number" in this case
        D2I = ((customer.getMonthlyDebtPayments()+payment))/(customer.getIncome()/12);
    }

    public boolean loanApproved(){
        boolean approved = true;

        //loan approval conditions
        if(getRate() >= RATETOOHIGH || (downPayment/cost) < MIN_PERCENT_DOWN || D2I > DTOITOOHIGH){
            approved = false;
        }

        return approved;
    }

    public double getPayment(){
        return payment;
    }

    public double getRate(){
        return rate;
    }

    public double getPrincipal(){
        return cost - downPayment;
    }

    public int getYears(){
        return years;
    }

    /**
     *
     * @return the monthly payment of the loan
     * @post payment >= 0
     */
    private double calc_payment(){
        //again enforcing that 12 was said to be ok as a "magic number"
        double numerator = ((rate/ 12)*getPrincipal());
        double denominator = 1 - Math.pow((1 + (rate/12)),-(years*12));

        return numerator / denominator;
    }

    /**
     *
     * @return the APR rate
     * @post 0 >= APR >= 1
     */
    private double calc_rate(){
        double APR = BASERATE;

        if(years < MAX_YEARS){
            APR += GOODRATEADD;
        }else{
            APR += NORMALRATEADD;
        }

        if((downPayment/cost) < PREFERRED_PERCENT_DOWN){
            APR += GOODRATEADD;
        }

        //credit score rate table
        if(customer.getCreditScore() < BADCREDIT){
            APR += VERYBADRATEADD;
        }else if(customer.getCreditScore() >= BADCREDIT && customer.getCreditScore() < FAIRCREDIT){
            APR += BADRATEADD;
        }else if(customer.getCreditScore() >= FAIRCREDIT && customer.getCreditScore() < GOODCREDIT){
            APR += NORMALRATEADD;
        }else if(customer.getCreditScore() >= GOODCREDIT && customer.getCreditScore() < GREATCREDIT){
            APR += GOODRATEADD;
        }

        return APR;
    }

}
